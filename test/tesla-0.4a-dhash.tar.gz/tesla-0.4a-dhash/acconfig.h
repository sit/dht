/*
 * TESLA: A Transparent, Extensible Session-Layer Architecture
 *
 * Jon Salz <jsalz@mit.edu>
 * Alex C. Snoeren <snoeren@lcs.mit.edu>
 *
 * Copyright (c) 2001-2 Massachusetts Institute of Technology.
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. For more information, see the `COPYING' file in the source
 * distribution.
 *
 * $Id: acconfig.h,v 1.2 2002/09/02 19:49:23 jsalz Exp $
 *
 */

/* Name of libc dynamic library */
#undef LIBC_NAME

/* Define to use GNU extensions if available. */
#undef _GNU_SOURCE

