/*
 * TESLA: A Transparent, Extensible Session-Layer Architecture
 *
 * Jon Salz <jsalz@mit.edu>
 * Alex C. Snoeren <snoeren@lcs.mit.edu>
 *
 * Copyright (c) 2001-2 Massachusetts Institute of Technology.
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. For more information, see the `COPYING' file in the source
 * distribution.
 *
 * $Id: top_handler.hh,v 1.12 2002/11/12 19:42:38 jsalz Exp $
 *
 * The top handler, which handles communication between the
 * application and the master process.
 *
 */

#ifndef HH_TOP_HANDLER
#define HH_TOP_HANDLER

#include "tesla/async.hh"
#include "tesla/flow_handler.hh"
#include "tesla/timer.hh"
#include <string>

using namespace std;

class top_handler : private async, public flow_handler {
private:
    int fd;
    int conn_id;
    flow_handler *h;

    // Bytes going to application
    string buffer;

    // Bytes coming from application to handlers (which we can't write yet)
    string wbuffer;

    int type;

    static info _info;

    // Never write again to application, e.g., application has called
    // shutdown(fd, SHUT_RD)
    bool shut_read;

    // Never read from application again, e.g., application has called
    // shutdown(fd, SHUT_WR)
    bool shut_write;

    // Connected?  (If not, delete this on shut_write)
    bool is_connected;

    bool closed;

    typedef method_timer<top_handler> my_timer;
    my_timer wbuffer_timer;
    unsigned long long total_bytes;

    void check_shutdown();

    void wbuffer_fire(my_timer&);

public:
    top_handler(int _fd, int _type, int _conn_id, flow_handler *_h);
    virtual ~top_handler();
    virtual int close();

    int get_fd() { return fd; }
    int get_conn_id() { return conn_id; }
    bool sendapp_or_buffer(const void *pp, int len);

    void set_fd(int fd) { this->fd = fd; async::set_fd(fd); set_ractive(true); }
    void set_conn_id(int conn_id) { this->conn_id = conn_id; }

    flow_handler *get_handler() { return h; }

    void sigpipe();

    virtual void ravail();
    virtual void wavail();
    virtual void connected(flow_handler *from, bool success);
    virtual void accept_ready(flow_handler *from);
    string getsockopt(int level, int optname, int maxlen);
    int setsockopt(int level, int optname, string value);
    int ioctl(string target, int optname, string value, string& out);
    address getpeername();
    address getsockname();
    virtual int shutdown(bool r, bool w);
    void got_sigpipe(flow_handler *from);

    virtual bool avail(flow_handler *from, data d);
    virtual void may_write(flow_handler *from, bool may);
    virtual bool may_exit();

    virtual bool save_state(oserial& out) const;

    void rewant() {
        set_ractive(may_write_now());
    }

    friend void freeze(iserial& in, const flow_handler& h);
    friend void unfreeze(iserial& in, flow_handler*& h);
};

#endif
