/*
 * TESLA: A Transparent, Extensible Session-Layer Architecture
 *
 * Jon Salz <jsalz@mit.edu>
 * Alex C. Snoeren <snoeren@lcs.mit.edu>
 *
 * Copyright (c) 2001-2 Massachusetts Institute of Technology.
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. For more information, see the `COPYING' file in the source
 * distribution.
 *
 * $Id: libc-dgram.c,v 1.6.2.3 2002/11/22 07:06:22 thomer Exp $
 *
 * Datagram-related libc overrides for the libtesla.so wrapper library.
 * #included by tesla.c.
 *
 */

int read(int fd, void *buf, size_t len) {
    if (tesla_enabled(0) && ts_fds[fd].wrapped &&
	((ts_fds[fd].type == SOCK_DGRAM) || ts_fds[fd].connecting ||
         ts_fds[fd].connect_status)) {

        // If connect failed, report that now
        if((errno = ts_fds[fd].connect_status))
            return -1;

        // We read an async socket that hasn't yet connected
        if(ts_fds[fd].connecting)
            ts_fatal("Read without select not yet supported");

        return recvfrom(fd, buf, len, 0, 0, 0);
    } else {
        return TS_CALL_LIBC(read, fd, buf, len);
    }

}

int recv(int fd, void *buf, size_t len, int flags) {
    if (tesla_enabled(0) && ts_fds[fd].wrapped &&
	((ts_fds[fd].type == SOCK_DGRAM) || ts_fds[fd].connecting ||
	 ts_fds[fd].connect_status)) {
        // If connect failed, report that now
        if((errno = ts_fds[fd].connect_status))
            return -1;
        // We read an async socket that hasn't yet connected
        if(ts_fds[fd].connecting)
            ts_fatal("Recv without select not yet supported");
        return recvfrom(fd, buf, len, flags, 0, 0);
    } else {
        return TS_CALL_LIBC(recv, fd, buf, len, flags);
    }
}


int
recvfrom(int fd, void *buf, size_t count, int flags,
	 struct sockaddr *from, socklen_t *fromlen)
{
    static char addr[ADDRESS_SIZE + sizeof(socklen_t)];
    static struct msghdr msg;
    static struct iovec iov[8];
    int ret;
    int cnt = 0;
    int orig_fromlen = *fromlen;

    if (!(tesla_enabled(0) && ts_fds[fd].wrapped &&
          ((ts_fds[fd].type == SOCK_DGRAM) || ts_fds[fd].connecting ||
           ts_fds[fd].connect_status)))
    {
        return TS_CALL_LIBC(recvfrom, fd, buf, count, flags, from, fromlen);
    }

    // If connect failed, report that now
    if((errno = ts_fds[fd].connect_status))
        return -1;
    // We read an async socket that hasn't yet connected
    if(ts_fds[fd].connecting)
        ts_fatal("Recvfrom without select not yet supported");

    if (flags)
        ts_fatal("TESLA doesn't support recvfrom/sendto flags");

    msg.msg_name = 0;
    msg.msg_namelen = 0;
    msg.msg_iov = iov;

    // First: Length of address
    iov[cnt].iov_base = fromlen;
    iov[cnt].iov_len = sizeof *fromlen;
    ++cnt;

    // Next: The address itself (if there is one)
    if (from && fromlen) {
        iov[cnt].iov_base = from;
        iov[cnt].iov_len = *fromlen < ADDRESS_SIZE ? *fromlen : ADDRESS_SIZE;
        ++cnt;
    }

    // Next: The rest of the address
    if (!fromlen || *fromlen < ADDRESS_SIZE) {
        // Address buffer not big enough - pad
        iov[cnt].iov_base = addr;
        iov[cnt].iov_len = fromlen ? ADDRESS_SIZE - *fromlen : ADDRESS_SIZE;
        ++cnt;
    }

    // Next: the data
    iov[cnt].iov_base = buf;
    iov[cnt].iov_len = count;
    ++cnt;

    msg.msg_iovlen = cnt;

    msg.msg_control = 0;
    msg.msg_controllen = 0;
    msg.msg_flags = 0;

    ret = TS_CALL_LIBC(recvmsg, fd, &msg, 0);
    if (fromlen && *fromlen > orig_fromlen)
        *fromlen = orig_fromlen;

    if (ret < ADDRESS_SIZE + sizeof(socklen_t)) {
        ts_error("recvmsg failed; message too short");
        return 0;
    }

    return ret - (ADDRESS_SIZE + sizeof(socklen_t));
}


int write(int fd, const void *buf, size_t len) {
    if (!tesla_enabled(0) || !ts_fds[fd].wrapped || ts_fds[fd].type != SOCK_DGRAM)
	return TS_CALL_LIBC(write, fd, buf, len);
    return sendto(fd, buf, len, 0, 0, 0);
}


int send(int fd, const void *buf, size_t len, int flags) {
    if (!tesla_enabled(0) || !ts_fds[fd].wrapped || ts_fds[fd].type != SOCK_DGRAM)
	return TS_CALL_LIBC(send, fd, buf, len, flags);
    return sendto(fd, buf, len, flags, 0, 0);
}


int
sendto(int fd, const void *buf, size_t count, int flags,
       const struct sockaddr *to, socklen_t tolen)
{
    static char garbage[ADDRESS_SIZE];
    static struct msghdr msg;
    static struct iovec iov[4];

    int cnt;
    int ret;

    if (!tesla_enabled(0) || !ts_fds[fd].wrapped || ts_fds[fd].type != SOCK_DGRAM)
	return TS_CALL_LIBC(sendto, fd, buf, count, flags, to, tolen);

    if (flags)
	ts_fatal("TESLA doesn't support recvfrom/sendto flags");

    // Essentially the same code in teslamaster::avail; consolidate?
    cnt = 0;
    msg.msg_name = 0;
    msg.msg_namelen = 0;
    msg.msg_iov = iov;

    // First four bytes: actual length of address
    iov[cnt].iov_base = &tolen;
    iov[cnt].iov_len = sizeof tolen;
    ++cnt;


    if (to && tolen) {
        // Send up to tolen bytes as the address
        ts_debug_2("have an address");
        iov[cnt].iov_base = (void*)to;
        iov[cnt].iov_len = tolen > ADDRESS_SIZE ? ADDRESS_SIZE : tolen;
        ++cnt;
    }
    if (tolen < ADDRESS_SIZE) {
        // Send some garbage, if we need to fill up the address field
        ts_debug_3("address not long enough - padding");
        iov[cnt].iov_base = garbage;
        iov[cnt].iov_len = ADDRESS_SIZE - tolen;
        ++cnt;
    }

    // Send the actual data
    ts_debug_3("data length is %d", count);
    iov[cnt].iov_base = (void*)buf;
    iov[cnt].iov_len = count;
    ++cnt;

    ts_debug_3("iovlen is %d", msg.msg_iovlen);
    msg.msg_iovlen = cnt;
    msg.msg_control = 0;
    msg.msg_controllen = 0;
    msg.msg_flags = 0;

    ret = TS_CALL_LIBC(sendmsg, fd, &msg, 0);

    if (ret == 0)
        return 0;
    if (ret < 0) {
        ts_error("Sendmsg failed: %s", strerror(errno));
        return -1;
    }
    if (ret == sizeof(socklen_t) + ADDRESS_SIZE + count) {
        errno = 0;
        return count;
    }

    ts_error("Sendmsg - partial send");
    errno = EINVAL;
    return -1;
}


/* XXX: The recv/sendmsg commands are much trickier */

int
recvmsg(int fd, struct msghdr *msg, int flags)
{
    if (flags != 0)
        ts_fatal("Recvmsg with flags not yet supported");

    // this is probably not the way to go
    if (tesla_enabled(0) && ts_fds[fd].wrapped &&
	((ts_fds[fd].type == SOCK_DGRAM) || ts_fds[fd].connecting ||
         ts_fds[fd].connect_status)) {
        int ret = 0;
        int i;


        // If connect failed, report that now
        if((errno = ts_fds[fd].connect_status)) {
            ts_debug_1("recvmsg, connect failed");
            return -1;
        }

        // We read an async socket that hasn't yet connected
        if(ts_fds[fd].connecting)
            ts_fatal("Read without select not yet supported");
        for(i=0; i<msg->msg_iovlen; i++) {
            int xxx;
            if((xxx = recvfrom(fd, msg->msg_iov[i].iov_base,
                            msg->msg_iov[i].iov_len, 0, 0, 0)) < 0)
                return -1;
            assert(xxx == msg->msg_iov[i].iov_len);
            ret += xxx;
        }
        return ret;
    } else {
        return TS_CALL_LIBC(recvmsg, fd, msg, flags);
    }
}

int
sendmsg(int fd, const struct msghdr *msg, int flags)
{
    char *buf = 0;
    unsigned bufsize = 0, offset = 0;
    int i = 0;
    int ret;

    if(flags != 0)
        ts_fatal("Sendmsg with flags not yet supported");

    // concatenate io_vec into one big buffer
    for(i=0; i<msg->msg_iovlen; i++) {
        unsigned len = msg->msg_iov[i].iov_len;
        bufsize += len;
        buf = realloc(buf, bufsize);
        memcpy(buf + offset, msg->msg_iov[i].iov_base, len);
        offset += len;
    }

    if (!tesla_enabled(0) || !ts_fds[fd].wrapped || ts_fds[fd].type != SOCK_DGRAM) {
	ret = TS_CALL_LIBC(sendto, fd, buf, bufsize, flags, msg->msg_name, msg->msg_namelen);
    } else {
        ret = sendto(fd, buf, bufsize, flags, msg->msg_name, msg->msg_namelen);
    }

    free(buf);
    return ret;
}
// vim: sw=4
