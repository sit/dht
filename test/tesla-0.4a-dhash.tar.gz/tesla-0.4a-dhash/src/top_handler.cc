/*
 * TESLA
 *
 * Jon Salz <jsalz@mit.edu>
 * Alex C. Snoeren <snoeren@lcs.mit.edu>
 *
 * Copyright (c) 2001-2 Massachusetts Institute of Technology.
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. For more information, see the `COPYING' file in the source
 * distribution.
 *
 * $Id: top_handler.cc,v 1.18.2.2 2002/11/22 07:06:22 thomer Exp $
 *
 * The top handler, which handles communication between the
 * application and the master process.
 *
 */

#include "config.h"

#include <set>

#include "tesla/tesla.h"
#include "tesla-internal.h"
#include "top_handler.hh"
#include "teslamaster.hh"

extern set<top_handler*> close_set;

top_handler::top_handler(int _fd, int _type, int _conn_id, flow_handler *_h) :
    async(_fd), flow_handler(init_context(_info, *(flow_handler*)0, -1, -1, -1), false),
    fd(_fd), conn_id(_conn_id), h(_h), type(_type),
    shut_read(false), shut_write(false),
    is_connected(false),
    closed(false),
    wbuffer_timer(this, &top_handler::wbuffer_fire),
    total_bytes(0LL)
{
    if (h) h->set_upstream(this);

    if (fd >= 0)
        set_ractive(true);
}

top_handler::~top_handler()
{
    ts_debug_1("Deleting top_handler (fd=%d)", fd);
    close();
    if (h)
        delete h;
}

// If we've been shut down in both directions, remember to close
// this handler off later
void top_handler::check_shutdown()
{
    if (!closed && (shut_read || !is_connected) && shut_write) {
        //    if (!closed && shut_read && shut_write) {
        ts_debug_1("Marking %d for later closing", fd);
        close_set.insert(this);
    }
}

int top_handler::close() {
    if (closed)
        return -1;

    closed = true;

    // Close connection to app
    ::close(fd);

    // Tell handler to close
    if (h)
        return h->close();

    return 0;
}

// Called when we get an EPIPE error writing to the application
void top_handler::sigpipe() {
    // No more bytes to write to application
	
    // Shut down the network stack; never read from stack again
    shutdown(true, false);

    shut_read = true;
    check_shutdown();
}

void top_handler::got_sigpipe(flow_handler *from) {
    // Never read from application again
    ::shutdown(fd, SHUT_RD);
    shut_write = true;
    set_ractive(false);
    check_shutdown();
}

// Called when bytes are available from application socket
void top_handler::ravail() {
    static char buf[MAX_DGRAM_SIZE];
    size_t bytes;

    if (type == SOCK_DGRAM) {
	// For datagrams, read up to the maximum datagram size
	bytes = ::read(fd, buf, sizeof buf);
    } else {
        // For non-datagrams, read up to DATA_BUFFER_SIZE bytes at a
        // time
        bytes = ::read(fd, buf, DATA_BUFFER_SIZE);
    }

    if (bytes <= 0) {
        ts_debug_1("Application has done shutdown(write) on %d", fd);

        // Don't bother reading any more bytes
        set_ractive(false);

        // Tell handlers they'll never be getting any more bytes
        h->shutdown(false, true);

        shut_write = true;
        check_shutdown();
        return;
    }

    total_bytes += bytes;

    int ret;
    if (type == SOCK_DGRAM) {
	if (bytes < ADDRESS_SIZE + sizeof(socklen_t)) {
	    // The packet wasn't long enough to contain the address!
	    ts_error("Packet from application too short");
	    set_ractive(false);
	    return;
	}

	// Construct a data object; address is the first few bytes
	// of the packet we received; actual data is the rest
	ret = h->write(data(buf + ADDRESS_SIZE + sizeof(socklen_t),
			    bytes - ADDRESS_SIZE - sizeof(socklen_t),
                            0,
			    (const sockaddr *)(buf + sizeof(socklen_t)),
			    *(const socklen_t *)buf));

        if (ret) ts_debug_1("Got error %s writing to stack", strerror(-ret));

        // Always succeeds
        return;
    } else {
        // Non-datagram: just throw the bytes down the chain
        ts_debug_2("Got bytes to write to flow_handler");

        if (wbuffer.length()) {
            wbuffer.append(buf, bytes);
            string w = wbuffer;
            wbuffer.erase();

            ret = h->write(data(wbuffer.data(), wbuffer.length()));
        } else {
            ret = h->write(data(buf, bytes));
        }
    }

    if (ret < 0) {
        ts_debug_1("Got error %s writing to stack", strerror(-ret));

        // Shut down the application
        set_ractive(false);
        ::shutdown(fd, SHUT_RD);
        shut_write = true;
        check_shutdown();
    }
}

void top_handler::wavail() {
    // We can write to the application now.  Presumably there's data
    // buffered in buffer (otherwise we wouldn't have called
    // set_wactive(true)).

    const char *p = buffer.data();
    int len = buffer.length();

    while (len > 0) {
        // Write as much as we can
        int written = ::write(fd, p, len);

        if (written == -1 && errno == EAGAIN) {
            // Can't write any more bytes; buffer the rest.  This
            // is pretty inefficient
            buffer = string(buffer, len, buffer.length());
            return;
        }
        if (written == -1 && errno == EPIPE) {
            // The other end of the pipe has closed (app has done
            // shutdown(fd, SHUT_READ))
            sigpipe();
            return;
        }

        if (written <= 0) {
            // Buffer whatever's left and bail.
            ts_debug_1("Buffering data...");
            buffer = string(buffer, len, buffer.length());
            set_wactive(false);
            set_ractive(true);
            return;
        }

        p += written;
        len -= written;
    }

    // We're done (len == 0).  Unthrottle downstream handlers,
    // and stop waiting for write availability to application.
    h->may_avail(true);
    set_wactive(false);
    set_ractive(true);
    buffer.resize(0);
}

void top_handler::connected(flow_handler *from, bool success) {
    // Write "B" or "A" to the app to indicate connection success
    // or failure
    if (type != SOCK_DGRAM)
        avail(from, success ? "B" : "A");

    if (success)
        is_connected = true;
}

void top_handler::accept_ready(flow_handler *from) {
    avail(from, "C");
}

string top_handler::getsockopt(int level, int optname, int maxlen) {
    if (!h) return string();
    return h->getsockopt(level, optname, maxlen);
}
int top_handler::setsockopt(int level, int optname, string value) {
    if (!h) return -1;
    return h->setsockopt(level, optname, value);
}
int top_handler::ioctl(string target, int optname, string value, string& out) {
    if (!h) return -EINVAL;
    return h->ioctl(target, optname, value, out);
}
address top_handler::getpeername() {
    if (!h) return address();
    return h->getpeername();
}
address top_handler::getsockname() {
    if (!h) return address();
    return h->getsockname();
}
    
// Need to write bytes to application.
bool top_handler::avail(flow_handler *from, data d) {
    if (d.length() == 0) {
        // No more bytes from stack
        ts_debug_1("Network has shutdown its writes on %d (errno=%d)", fd, d.error());

        if (!shut_read) {
            // Never read from stack again
            shut_read = true;
            // Never write to the application again
            ::shutdown(fd, SHUT_WR);
            check_shutdown();
        }

        return false;
    }

    if (type == SOCK_DGRAM) {
        ts_debug_2("avail sock_dgram");

	static char garbage[ADDRESS_SIZE];
	static struct msghdr msg;
	static struct iovec iov[4];
	socklen_t addrlen = d.addrlen();

	// Construct the datagram with the address at the beginning
	// followed by the payload
	int cnt = 1;
	msg.msg_name = 0;
	msg.msg_namelen = 0;
	msg.msg_iov = iov;
	iov[0].iov_base = (char*) &addrlen;
	iov[0].iov_len = sizeof addrlen;
	if (d.addr() && d.addrlen()) {
	    ts_debug_2("have an address");
	    iov[cnt].iov_base = (char*) d.addr();
	    iov[cnt].iov_len = d.addrlen() > ADDRESS_SIZE ? ADDRESS_SIZE : d.addrlen();
	    ++cnt;
	}
	if (d.addrlen() < ADDRESS_SIZE) {
	    ts_debug_2("address not long enough - padding");
	    iov[cnt].iov_base = garbage;
	    iov[cnt].iov_len = ADDRESS_SIZE - d.addrlen();
	    ++cnt;
	}
	ts_debug_2("data length is %d", d.length());
	iov[cnt].iov_base = (char*) d.bits();
	iov[cnt].iov_len = d.length();
	++cnt;

	ts_debug_2("iovlen is %d", msg.msg_iovlen);
	msg.msg_iovlen = cnt;
	msg.msg_control = 0;
	msg.msg_controllen = 0;
	msg.msg_flags = 0;

	int ret = ::sendmsg(fd, &msg, 0);
	if (ret <= 0)
	    ts_error("Sendmsg failed: %s", strerror(errno));
	return ret > 0;
    }

    return sendapp_or_buffer(d.bits(), d.length());
}

bool top_handler::sendapp_or_buffer(const void *pp, int len) {
    const char *p = (const char *)pp;

    if (buffer.size() != 0) {
        buffer.append(p, len);
        return true;
    }

    while (len > 0) {
        int written = ::write(fd, p, len);

        ts_debug_2("- system avail call on %d returned %d (out of %d)", fd, written, len);

        if (written == -1 && errno == EAGAIN) {
            ts_debug_2("  - buffering remaining %d bytes", len);

            // buffer the rest, select on write, and throttle downstream
            buffer.append(p, len);
            set_wactive(true);
            h->may_avail(false);
            return true;
        }

        if (written <= 0) {
            ts_debug_2("  - closed for writing");

            // closed for writing
            return false;
        }

        ts_debug_2("  - wrote %d bytes successfully", written);
	
        p += written;
        len -= written;
    }

    return true;
}

void top_handler::may_write(flow_handler *from, bool may) {
    // If we get a may_write(false), don't bother reading from the
    // application.
    can_write = may;
    set_ractive(may);

    if (may && wbuffer.length()) {
        wbuffer_timer.arm(0);
    }
}

void top_handler::wbuffer_fire(my_timer&) {
    if (h && can_write && wbuffer.length()) {
        string r = wbuffer;
        wbuffer.erase();
        h->write(data(r.data(), r.length()));
    }
}

bool top_handler::may_exit() {
    if (!h) return true;

    // Before exiting, we have to handle any buffered
    // bytes from the app
    if (type != SOCK_DGRAM) {
        // Drain all bytes from application
        char buf[DATA_BUFFER_SIZE];
        int bytes;

        while ((bytes = ::read(fd, buf, sizeof buf)) > 0) {
            wbuffer.append(buf, bytes);
        }
        if (wbuffer.length()) {
            // Can't exit since there are still bytes to write!
            if (can_write)
                wbuffer_timer.arm(0);

            return false;
        }
    }

    return h->may_exit();
}

bool top_handler::save_state(oserial& out) const {
    string rbuf;

    if (type != SOCK_DGRAM) {

        // Drain all bytes from application
        char buf[DATA_BUFFER_SIZE];
        int bytes;

        while ((bytes = ::read(fd, buf, sizeof buf)) > 0) {
            rbuf.append(buf, bytes);
        }
    
    }

    ts_debug_1("Top handler save state: drained %d bytes from the app; %d bytes in ->app buffer",
               rbuf.length(), buffer.length());
    ts_debug_1("rbuf is \"%s\"; buffer is \"%s\"", rbuf.c_str(), buffer.c_str());

    // rbuf = bytes read from application
    return out << rbuf << buffer << *h;
}

int
top_handler::shutdown(bool r, bool w) {
    if (h)
        return h->shutdown(r,w);
    else
        return 0;
}

flow_handler::info top_handler::_info("top_handler", "top_handler", "", -1, -1, 0);
