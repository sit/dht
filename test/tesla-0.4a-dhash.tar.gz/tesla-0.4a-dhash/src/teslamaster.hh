/*
 * TESLA: A Transparent, Extensible Session-Layer Architecture
 *
 * Jon Salz <jsalz@mit.edu>
 * Alex C. Snoeren <snoeren@lcs.mit.edu>
 *
 * Copyright (c) 2001-2 Massachusetts Institute of Technology.
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. For more information, see the `COPYING' file in the source
 * distribution.
 *
 * $Id: teslamaster.hh,v 1.2 2002/08/30 20:35:37 jsalz Exp $
 *
 * The master process.
 *
 */

#ifndef HH_TESLAMASTER
#define HH_TESLAMASTER

int read_fully(int fd, void *buf, int count);
int write_fully(int fd, const void *buf, int count);

#endif
