#!/bin/sh

# Usage:
#
# test.sh snoeren@ipaq1
# test.sh eep

make dist
ssh $1 'rm -rf tesla-test ; mkdir tesla-test ; cd tesla-test ; gunzip -c | tar xfv - ; cd tesla-* ; ./configure --prefix=$HOME/tesla-test ; (gmake || make) && (gmake install || make install) && $HOME/tesla-test/bin/tesla +log lynx -dump http://web.mit.edu/xyzzyfoo' < tesla.tar.gz
