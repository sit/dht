/*
 * TESLA: A Transparent, Extensible Session-Layer Architecture
 *
 * Jon Salz <jsalz@mit.edu>
 * Alex C. Snoeren <snoeren@lcs.mit.edu>
 *
 * Copyright (c) 2001-2 Massachusetts Institute of Technology.
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. For more information, see the `COPYING' file in the source
 * distribution.
 *
 * $Id: crypt_handler.cc,v 1.4 2002/09/02 18:38:16 jsalz Exp $
 *
 * A really dumb triple-DES encryption handler.
 *
 */

#include "config.h"

#include "crypt_handler.hh"

DEFINE_HANDLER(crypt, crypt_handler, AF_INET, SOCK_STREAM);

HANDLER_USAGE(crypt_handler,

"A pretty dumb triple-DES encryption handler.\n"
"\n"
"(no flags)\n"

	      );
