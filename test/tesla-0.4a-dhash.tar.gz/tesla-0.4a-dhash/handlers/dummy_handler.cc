/*
 * TESLA: A Transparent, Extensible Session-Layer Architecture
 *
 * Jon Salz <jsalz@mit.edu>
 * Alex C. Snoeren <snoeren@lcs.mit.edu>
 *
 * Copyright (c) 2001-2 Massachusetts Institute of Technology.
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. For more information, see the `COPYING' file in the source
 * distribution.
 *
 * $Id: dummy_handler.cc,v 1.5 2002/09/02 18:38:16 jsalz Exp $
 *
 * A dummy handler, useful for testing.
 *
 */

#include "config.h"

#include "dummy_handler.hh"

DEFINE_HANDLER(dummy, dummy_handler, AF_INET, SOCK_STREAM);
DEFINE_HANDLER(dummyudp, dummy_udp_handler, AF_INET, SOCK_DGRAM);
HANDLER_USAGE(dummy_handler,

"A no-operation handler useful for debugging.\n"
"\n"
"(no flags)\n"

	      );
HANDLER_USAGE(dummy_udp_handler,

"A no-operation handler useful for debugging.\n"
"\n"
"(no flags)\n"

	      );
