
#include "msg_handler.hh"

DEFINE_HANDLER(msg, msg_handler, AF_INET, SOCK_STREAM);
