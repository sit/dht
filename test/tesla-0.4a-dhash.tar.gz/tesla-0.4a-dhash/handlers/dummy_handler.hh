/*
 * TESLA: A Transparent, Extensible Session-Layer Architecture
 *
 * Jon Salz <jsalz@mit.edu>
 * Alex C. Snoeren <snoeren@lcs.mit.edu>
 *
 * Copyright (c) 2001-2 Massachusetts Institute of Technology.
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. For more information, see the `COPYING' file in the source
 * distribution.
 *
 * $Id: dummy_handler.hh,v 1.4 2002/08/30 20:35:37 jsalz Exp $
 *
 * A dummy handler, useful for testing.
 *
 */

#ifndef HH_DUMMY_HANDLER
#define HH_DUMMY_HANDLER

#include "tesla/flow_handler.hh"

#include <sys/socket.h>

class dummy_handler : public flow_handler {
public:
    dummy_handler(init_context& ctxt) : flow_handler(ctxt) {}

    DECLARE_HANDLER;
};

class dummy_udp_handler : public flow_handler {
public:
    dummy_udp_handler(init_context& ctxt) : flow_handler(ctxt) {}

    DECLARE_HANDLER;
};

#endif
