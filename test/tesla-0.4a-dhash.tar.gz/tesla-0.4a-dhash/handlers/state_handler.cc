/*
 * TESLA: A Transparent, Extensible Session-Layer Architecture
 *
 * Jon Salz <jsalz@mit.edu>
 * Alex C. Snoeren <snoeren@lcs.mit.edu>
 *
 * Copyright (c) 2001-2 Massachusetts Institute of Technology.
 *
 * This software is being provided by the copyright holders under the GNU
 * General Public License, either version 2 or, at your discretion, any later
 * version. For more information, see the `COPYING' file in the source
 * distribution.
 *
 * $Id: state_handler.cc,v 1.1 2002/09/25 04:18:40 jsalz Exp $
 *
 * A state handler, useful for testing.
 *
 */

#include "config.h"

#include "state_handler.hh"

DEFINE_HANDLER(state, state_handler, AF_INET, SOCK_STREAM);
HANDLER_USAGE(state_handler,

"A no-operation handler useful for debugging.\n"
"\n"
"(no flags)\n"

	      );

